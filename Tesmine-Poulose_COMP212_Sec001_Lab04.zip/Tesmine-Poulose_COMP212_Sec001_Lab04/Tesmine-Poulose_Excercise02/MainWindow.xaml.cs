﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tesmine_Poulose_Excercise02
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, RoutedEventArgs e)
        {
            var name = txtName.Text;
            if (name.Length == 0)
            {
                txtOutput.Text = "ERROR: Name not provided";
                return;
            }
            var address = "";
            try
            {
                address = ((ComboBoxItem)comboAddress.SelectedItem).Content.ToString();
            }
            catch (Exception) { }


            //calculating prices when address is selected 
            var addressDiscount = 0;
            if (address.Contains("Alberta"))
            {
                addressDiscount = 7;
            }
            else if (address.Contains("Ontario"))
            {
                addressDiscount = 13;
            }
            else if (address.Contains("Quebec"))
            {
                addressDiscount = 6;
            }
            else
            {
                txtOutput.Text = "ERROR: Address not selected";
                return;
            }
            //calculating prices when age group is selected
            var ageDiscount = 0;
            if (radioKid.IsChecked == true)
            {
                ageDiscount = 15;
            }
            else if (radioSenior.IsChecked == true)
            {
                ageDiscount = 10;
            }
            else if (radioAdult.IsChecked == true)
            {
                ageDiscount = 0;
            }
            else
            {
                txtOutput.Text = "ERROR: Age not selected";
                return;
            }
            //calculating prices when services are selected
            var services = 0;

            if (checkboxFlossing.IsChecked == true)
            {
                services = services = 20;
            }
            if (checkboxFilling.IsChecked == true)
            {
                services = services + 75;
            }
            if (checkboxRootCanal.IsChecked == true)
            {
                services = services + 150;
            }

            if (services == 0)
            {
                txtOutput.Text = "ERROR: Please select a service!!";
                return;
            }

            // if inputs are correct

            var finalDiscount = ageDiscount + addressDiscount;
            var finalPrice = services * (double)(100 - finalDiscount) / 100;

            txtOutput.Text = string.Format($"Hii {txtName.Text}!! Your final price is ${finalPrice}");
        }
    }
    }
