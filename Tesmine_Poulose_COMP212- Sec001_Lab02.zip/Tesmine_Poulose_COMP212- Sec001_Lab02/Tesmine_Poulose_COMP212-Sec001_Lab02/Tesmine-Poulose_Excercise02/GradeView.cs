﻿using System;
using System.Linq;

//coded by Tesmine Poulose 301151876
namespace tesmine_poulose_excercise02
{
    class GradeView
    {
        // GradesPredicate which takes one input of type double and returns a bool
        public delegate bool GradesPredicate(double grade);

        static void Main(string[] args)
        {
          //  student’s grade array having at least 10 double values between 10 and 100
            double[] gradeArray = { 50.0, 26.5, 18.5, 64, 12, 167.5, 7.5, 8.6, 197 };
            //returns the avaue greater than 50
            GradesPredicate gradesPredicate = (grade) => { return grade >= 50.0; };
            
            GradesFilter(gradeArray, gradesPredicate);
            Console.ReadLine();
        }
        ///GradesFilter which displays only those grades values which are greater than or equal to 50
        public static void GradesFilter(double[] gradeArray,GradesPredicate gradesPredicate)
        {
            var filteredGradeArray = gradeArray.Where(grade => gradesPredicate(grade));
            foreach (var grade in filteredGradeArray)
            {
                
                Console.WriteLine(grade);
            }
        }
    }//end of class
}//end of name space
