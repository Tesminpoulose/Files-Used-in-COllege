﻿
namespace exercise02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textoutput = new System.Windows.Forms.TextBox();
            this.calcluate = new System.Windows.Forms.Button();
            this.textfactoral = new System.Windows.Forms.TextBox();
            this.labelget = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBoxinput = new System.Windows.Forms.TextBox();
            this.textBoxDuration = new System.Windows.Forms.TextBox();
            this.textBoxRate = new System.Windows.Forms.TextBox();
            this.textBoxLoan = new System.Windows.Forms.TextBox();
            this.labelDuration = new System.Windows.Forms.Label();
            this.labelRate = new System.Windows.Forms.Label();
            this.labelLoan = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textoutput);
            this.groupBox1.Controls.Add(this.calcluate);
            this.groupBox1.Controls.Add(this.textfactoral);
            this.groupBox1.Controls.Add(this.labelget);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 39);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(334, 286);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Calculate Asynchronously";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // textoutput
            // 
            this.textoutput.Location = new System.Drawing.Point(52, 197);
            this.textoutput.Name = "textoutput";
            this.textoutput.Size = new System.Drawing.Size(223, 26);
            this.textoutput.TabIndex = 3;
            // 
            // calcluate
            // 
            this.calcluate.Location = new System.Drawing.Point(108, 114);
            this.calcluate.Name = "calcluate";
            this.calcluate.Size = new System.Drawing.Size(113, 36);
            this.calcluate.TabIndex = 2;
            this.calcluate.Text = "Calculate";
            this.calcluate.UseVisualStyleBackColor = true;
            this.calcluate.Click += new System.EventHandler(this.calcluate_Click);
            // 
            // textfactoral
            // 
            this.textfactoral.Location = new System.Drawing.Point(198, 46);
            this.textfactoral.Name = "textfactoral";
            this.textfactoral.Size = new System.Drawing.Size(100, 26);
            this.textfactoral.TabIndex = 1;
            // 
            // labelget
            // 
            this.labelget.AutoSize = true;
            this.labelget.Location = new System.Drawing.Point(6, 46);
            this.labelget.Name = "labelget";
            this.labelget.Size = new System.Drawing.Size(104, 19);
            this.labelget.TabIndex = 0;
            this.labelget.Text = "Get Factoral of:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.textBoxinput);
            this.groupBox2.Controls.Add(this.textBoxDuration);
            this.groupBox2.Controls.Add(this.textBoxRate);
            this.groupBox2.Controls.Add(this.textBoxLoan);
            this.groupBox2.Controls.Add(this.labelDuration);
            this.groupBox2.Controls.Add(this.labelRate);
            this.groupBox2.Controls.Add(this.labelLoan);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(380, 39);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(408, 286);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Car Loan calculator";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(327, 97);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 71);
            this.button1.TabIndex = 7;
            this.button1.Text = "Calculate Interest";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxinput
            // 
            this.textBoxinput.Location = new System.Drawing.Point(124, 228);
            this.textBoxinput.Name = "textBoxinput";
            this.textBoxinput.Size = new System.Drawing.Size(100, 26);
            this.textBoxinput.TabIndex = 6;
            // 
            // textBoxDuration
            // 
            this.textBoxDuration.Location = new System.Drawing.Point(183, 169);
            this.textBoxDuration.Name = "textBoxDuration";
            this.textBoxDuration.Size = new System.Drawing.Size(100, 26);
            this.textBoxDuration.TabIndex = 5;
            // 
            // textBoxRate
            // 
            this.textBoxRate.Location = new System.Drawing.Point(183, 114);
            this.textBoxRate.Name = "textBoxRate";
            this.textBoxRate.Size = new System.Drawing.Size(100, 26);
            this.textBoxRate.TabIndex = 4;
            // 
            // textBoxLoan
            // 
            this.textBoxLoan.Location = new System.Drawing.Point(183, 53);
            this.textBoxLoan.Name = "textBoxLoan";
            this.textBoxLoan.Size = new System.Drawing.Size(100, 26);
            this.textBoxLoan.TabIndex = 3;
            // 
            // labelDuration
            // 
            this.labelDuration.AutoSize = true;
            this.labelDuration.Location = new System.Drawing.Point(38, 169);
            this.labelDuration.Name = "labelDuration";
            this.labelDuration.Size = new System.Drawing.Size(61, 19);
            this.labelDuration.TabIndex = 2;
            this.labelDuration.Text = "Duration";
            // 
            // labelRate
            // 
            this.labelRate.AutoSize = true;
            this.labelRate.Location = new System.Drawing.Point(35, 114);
            this.labelRate.Name = "labelRate";
            this.labelRate.Size = new System.Drawing.Size(81, 19);
            this.labelRate.TabIndex = 1;
            this.labelRate.Text = "Interest rate";
            // 
            // labelLoan
            // 
            this.labelLoan.AutoSize = true;
            this.labelLoan.Location = new System.Drawing.Point(25, 53);
            this.labelLoan.Name = "labelLoan";
            this.labelLoan.Size = new System.Drawing.Size(91, 19);
            this.labelLoan.TabIndex = 0;
            this.labelLoan.Text = "Loan Amount";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Asynchronous Programming";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label labelget;
        private System.Windows.Forms.TextBox textfactoral;
        private System.Windows.Forms.Button calcluate;
        private System.Windows.Forms.TextBox textoutput;
        private System.Windows.Forms.Label labelDuration;
        private System.Windows.Forms.Label labelRate;
        private System.Windows.Forms.Label labelLoan;
       
        private System.Windows.Forms.TextBox textBoxinput;
        private System.Windows.Forms.TextBox textBoxDuration;
        private System.Windows.Forms.TextBox textBoxRate;
        private System.Windows.Forms.TextBox textBoxLoan;
        private System.Windows.Forms.Button button1;
    }
}
