﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using System.Windows.Forms;

namespace exercise02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
        }

        private async void calcluate_Click(object sender, EventArgs e)
        {
            BigInteger number = BigInteger.Parse(textfactoral.Text);
            Task<BigInteger> task1 = Task.Run(() => Factorial(number));
            await Task.WhenAll(task1);
            // display result
           textoutput.Text = task1.Result.ToString();
        }

        private BigInteger Factorial(BigInteger number)
        {
            BigInteger result = new BigInteger(1);
            BigInteger startValue = new BigInteger(1);
            for (; startValue <= number; startValue++)
            {
                result = result * startValue;
            }
            return result;
}
        

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            float loanAmt = float.Parse(textBoxLoan.Text);
            float intRate = float.Parse(textBoxRate.Text);
            int months = int.Parse(textBoxDuration.Text);
            interest(loanAmt, intRate, months);
        }
        private void interest(float loanAmount, float intrRate, int month)
        {
            float interestRate = (loanAmount * intrRate * month) / 100;
            textBoxinput.Text = interestRate.ToString();
        }
        
    }

}
