﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise05
{
    class Numbers
    {
        static void Main(string[] args)
        {
            //getting random numbers
            var r = new Random();

            //array with elements of random integers between 1-500
            int[] values = Enumerable.Range(1, 10000000)
                                     .Select(x => r.Next(1, 501))
                                     .ToArray();



            // Calculating time taken using LINQ
            Console.WriteLine(".................Time Calculation........\n");
            Console.WriteLine("Time taken to calculate Sum in LINQ");
            Console.WriteLine(".............................................................");
            Console.WriteLine();
            var linqStartTime = DateTime.Now;
            var linqEndTime = DateTime.Now;
            long linqTotal = values.Sum();
            var linqTimeDuration = linqEndTime.Subtract(linqStartTime).TotalMilliseconds;
            Results(linqTotal, linqTimeDuration);

            //Calculating time taken Using PLINQ 
            Console.WriteLine("-----------------------------------------------------------");
            Console.WriteLine();
            Console.WriteLine("\nTime to calculate Sum in PLINQ");
            Console.WriteLine("-----------------------------------------------------------");
            Console.WriteLine();
            var plinqStartTime = DateTime.Now;
            var plinqEndTime = DateTime.Now;
            var plinqTotal = values.AsParallel().Sum();
            var plinqTimeDuration = plinqEndTime.Subtract(plinqStartTime).TotalMilliseconds;
             Results(plinqTotal, plinqTimeDuration);

            //Time taken to Count distinct element using LINQ

            Console.WriteLine("\nTotal time to Count distinct element using LINQ");
            Console.WriteLine("-----------------------------------------------------------");
            Console.WriteLine();
            var linqStartTime1 = DateTime.Now;
            int linqDistinct = values.Distinct().Count();
            var linqEndTime1 = DateTime.Now;


            var linqTimeDuration1 = linqEndTime1.Subtract(linqStartTime1).TotalMilliseconds;
            Results(linqDistinct, linqTimeDuration1);
            Console.WriteLine("\nTotal  tome to Count distinct element using PLINQ: ");
            Console.WriteLine("-----------------------------------------------------------");
            Console.WriteLine();
            var plinqStartTime1 = DateTime.Now;
            int plinqDistinct = values.AsParallel().Distinct().Count();
            var plinqEndTime1 = DateTime.Now;
            var plinqTime1 = plinqEndTime1.Subtract(plinqStartTime1).TotalMilliseconds;
            Results(plinqDistinct, plinqTime1);
        }

        //displaying results
        static void Results(long sum, double times)
        {
            Console.WriteLine($"Sum: {sum:F}\nTotal time: {times:F}");
        }
    }
    static class extension
    {
        // extension method that sums up all elements
        public static long Sum(this IEnumerable<int> data)
        {
            long sum = 0;
            foreach (var val in data)
            {
                sum = sum + val;
            }

            return sum;
        }
    }

}//end of namespace

