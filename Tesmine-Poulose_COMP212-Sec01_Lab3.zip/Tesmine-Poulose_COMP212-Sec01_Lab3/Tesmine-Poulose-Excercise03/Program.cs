﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace excercise03
{
    class Program
    {
        static void Main(string[] args)
        {

            List<int> numbers = new List<int>();
            Random rnd = new Random();

            for (int i = 0; i < 10; i++)
            {
                // return from 1 to 100
                numbers.Add(rnd.Next(100) + 1);
            }

            //display the values in the list
            Console.WriteLine();
            Console.WriteLine("Random List of Numbers\n");
            Console.WriteLine("........................................................");
            Console.WriteLine();
            foreach (var i in numbers)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
           
            Console.WriteLine();

            //find all values in the above list which are greater than 50 and add 10
            var updatedNumbers = numbers.Select(number => MapFliter(number)).ToList();
            //display the values in the list

            Console.WriteLine(" Displaying the Sorted list of values after adding 10 to the numbers greater than 50 in the list\n");
            Console.WriteLine("........................................................");
            Console.WriteLine();
            updatedNumbers.Sort();
            foreach (var i in updatedNumbers)
            {
                Console.Write(i + " ");
            }
            Console.WriteLine();
            Console.ReadLine();
        }

        public static int MapFliter(int value)
        {
            if (value > 50)
            {
                return value + 10;
            }
            return value;
        }
    }
    }

