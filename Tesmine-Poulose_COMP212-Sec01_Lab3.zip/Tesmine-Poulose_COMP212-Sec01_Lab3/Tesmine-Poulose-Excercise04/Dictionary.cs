﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;


//coded by tesmine poulose

namespace excercise04
{
    class SortedDictionary
    {

        private static void DisplayDuplicateValue(SortedDictionary<string, int> duplicatedictionary)
        {
            Console.WriteLine("......Displaying duplicate words...........\n");
            Console.WriteLine("Duplicate words are: ");
            foreach (var key in duplicatedictionary.Keys)
            {
                if (duplicatedictionary[key] > 1)
                {
                    Console.WriteLine(string.Join(",", key));
                }
            }
        }

        // User input
        private static SortedDictionary<string, int> Words()
        {
            // new sorted dictionary
            var sortdictionary = new SortedDictionary<string, int>();

            // input from user
            Console.WriteLine("Enter a string value : ");

            // read input from the user
            string input = Console.ReadLine();

            // split input string 
            string[] words = Regex.Split(input, @"\s+");

            // processing user input words
            foreach (var word in words)
            {
                
                var key = word.ToLower();

                
                if (sortdictionary.ContainsKey(key))
                {
                    //pre-increment function
                    ++sortdictionary[key];
                }
                else
                {
                    // add new word to the dictionary
                    sortdictionary.Add(key, 1);
                }
            }

            return sortdictionary;
        }

        // displaying content
        private static void DisplayDictionary<Key, Value>(
           SortedDictionary<Key, Value> dictionary)
        {
            Console.WriteLine( $"\nSorted dictionary contains:\n{"Key",-18}{"Value",-18}");


            foreach (var key in dictionary.Keys)
            {
                Console.WriteLine($"{key,-15}{dictionary[key],-15}");
            }

            Console.WriteLine($"\nSize of the dictionary: {dictionary.Count}\n");
        }
        //main method
        static void Main()
        {
            // creating dictionary using input values 

            SortedDictionary<string, int> sorteddictionary = Words();

            // displays the string value
            DisplayDictionary(sorteddictionary);

            // displays duplicate value
            DisplayDuplicateValue(sorteddictionary);
        }//end of main
    }//end of class

}//end of namespace