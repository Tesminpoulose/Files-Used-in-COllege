﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Coded by TesminePoulose

namespace exercise01
{
    class Invoice
    {
        //declaring properties

        public int PartNumber { get; set; }
        public string PartDescription { get; set; }
        public int Quantityofitem { get; set; }

        public decimal Price { get; set; }

        // constructor with four parameter
        public Invoice(int partnumber, string partdescription, int quantity, decimal price)
        {
            PartNumber = partnumber;
            PartDescription = partdescription;
            Quantityofitem = quantity;
            Price = price;
        }
        public override string ToString() => $"{PartNumber,-12} {PartDescription,-22} {Quantityofitem,-12} {Price,-12}";



        static void Main()
        {

            // initialize array of invoices
            var invoice = new[] {
         new Invoice(87, "Electric Sander", 7, 57.98M),
         new Invoice(24, "Power Saw", 18, 99.99M),
         new Invoice(7, "Sledge Hammer", 11, 21.50M),
         new Invoice(77, "Hammer", 76, 11.99M),
         new Invoice(39, "Lawn Mover", 3, 79.50M),
         new Invoice(68, "Screw Driver", 106, 6.99M),
         new Invoice(56, "Jig Saw", 21, 11.00M)
         };

            Console.WriteLine("...................DISPLAYING INVOICE DETAILS...............\n");
            
            foreach (var item in invoice)
            {
                Console.WriteLine(item);
                Console.WriteLine("-------------------------------------------------------");
            }

            //displaying the details of PartDescription and Total price using the query LINQ
            var invoiceDetails =
                   from i in invoice
                   orderby i.Quantityofitem * i.Price
                   select new { PartDescription = i.PartDescription, Total = i.Quantityofitem * i.Price };

                foreach (var element in invoiceDetails)
                {
                    Console.WriteLine($"{element.PartDescription,-22} {element.Total}");
                }

                //listing the items using ascending order

                Console.WriteLine();
                var partDesc =
                   from inv in invoice
                   orderby inv.Quantityofitem ascending
                   select inv.PartDescription;

                // to determinte the item with the highest quantity using Last()

                Console.WriteLine($"Part Description with highest quantity: {partDesc.Last()}");
                Console.WriteLine();

                //determining the average of Price 

                var average =
                   from i in invoice
                   select (i.Price);
                decimal total = 0;
                foreach (var element in average)
                {
                    total = total + element;
                }

                Console.WriteLine($"Average price of the item is: {Math.Round(total / average.Count(), 2)}");

            }
        }
    }

   