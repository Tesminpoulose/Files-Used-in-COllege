﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tesmine_Poulose_Ex02
{
    public static class StringBuilderExtensions
    {

        //method declaration
        public static int CharCount(this StringBuilder strbuilder)
        {
            //initialising an int variable named wordCounter to 0.
            int CharCount = 0;
            //using strbuilder we are splitting words in text_array to count easily
            string[] text_array = strbuilder.ToString().Split(' ');


            if (text_array.Length > 0)
            {
                //if length of text_array greater than 0, charCounter is assigned its corresponding length
                CharCount = text_array.Length;
            }
            //return charCounter
            return CharCount;

        } //end of charcount method
    } //end of class StringBuilderExtension
}
