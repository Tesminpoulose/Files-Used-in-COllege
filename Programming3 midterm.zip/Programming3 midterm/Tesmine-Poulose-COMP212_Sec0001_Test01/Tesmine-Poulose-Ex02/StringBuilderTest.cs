﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tesmine_Poulose_Ex02
{
    class StringBuilderTest
    {
        //main method
        static void Main(string[] args)
        {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.Append("This is to test whether the extension method count can return a right answer or not");
            Console.WriteLine($"character count for the first string is :  {stringBuilder1.CharCount()}");

            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.Append("You can define extension methods for user defined types as well as predefined types");
            Console.WriteLine($"character count for second string is : {stringBuilder2.CharCount()}");

            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.Append("Hello I am Tesmine");
            Console.WriteLine($"character count count for third string is : {stringBuilder3.CharCount()}");


        }      //end of main method
    }         //end of class Strin
}//end of namespace
