﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tesmine_Poulose_Ex004
{
    class Program
    {
        static Func<string, string, string, string> Maximum = (string1, string2, string3) =>
        {
            if (string.Compare(string1, string2, StringComparison.OrdinalIgnoreCase) > 0 && string.Compare(string1, string3, StringComparison.OrdinalIgnoreCase) > 0)
            {
                return string1;
            }
            else if (string.Compare(string2, string1, StringComparison.OrdinalIgnoreCase) > 0 && string.Compare(string2, string3, StringComparison.OrdinalIgnoreCase) > 0)
            {
                return string2;
            }
            else
            {
                return string3;
            }

        };

        static void Main(string[] args)
        {
            Console.WriteLine("The highest of three string values");
            //finding the  smallest of three string values. 
            Console.WriteLine(Maximum("Iamtesmine", "Midterm", "Programming3"));
            Console.WriteLine("\nPrime numbers\n");

            Func<int, bool> checkPrimeNumber = x =>
            {
                bool isPrime = false;
                int i;
                //checking the condition for prime
                for (i = 2; i <= x - 1; i++)
                {
                    if (x % i == 0)
                    {
                        isPrime = false;
                        break;
                    }
                }
                if (i == x)
                {
                    isPrime = true;
                }
                return isPrime;
            };

            Console.WriteLine("Enter a number");
            int number = Convert.ToInt32(Console.ReadLine());

            bool isPrimeNumber = checkPrimeNumber(number);
            Console.WriteLine($"{number } is {(isPrimeNumber ? "" : "not")} prime number");
            Console.ReadKey();
        }
    }//end of class
}//end of namespace

