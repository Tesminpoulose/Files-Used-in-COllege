﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tesmine_Poulose_Ex03
{
    class program
    {

        public static T[] SubArray<T>(T[] a, int startIndexvalue, int endIndexvalue)
        {
            T[] result = new T[0];
            //checking index value
            if (startIndexvalue < 0)
            {
                Console.WriteLine("Index starting should not be negative");
                return result;
            }
            if (startIndexvalue > a.Length)
            {
                Console.WriteLine("Index starting should not be greater than array size.");
                return result;
            }
            if (endIndexvalue < 0)
            {
                Console.WriteLine("Index ending should not be negative");
                return result;
            }
            if (endIndexvalue < startIndexvalue)
            {
                Console.WriteLine("Index ending should not be less than startIndex");
                return result;
            }
            if (endIndexvalue > a.Length)
            {
                Console.WriteLine("End index should not be greater than array size");
                return result;
            }

            result = new T[endIndexvalue - startIndexvalue - 1];
            Array.Copy(a, startIndexvalue + 1, result, 0, endIndexvalue - startIndexvalue - 1);

            return result;
        }
        //main method
        public static void Main(string[] args)
        {
            // Use generic method to test integer array
            int[] array1 = new int[] { 8, 13, 55, 27, 19, 31 };
            int[] subArray1 = SubArray(array1, 3, 5);

            foreach (int a in subArray1)
            {
                Console.Write(a + "     ");
            }

            // Use generic method to test double array
            double[] array2 = new double[] { 1.5, 3.50, 5.6, 7.93, 9.7, 11.32 };
            double[] subArray2 = SubArray(array2, 1, 3);

            Console.WriteLine();
            foreach (int a in subArray2)
            {
                Console.Write(a + " ");
            }
        }//end of classs
    }
}//end of name space
