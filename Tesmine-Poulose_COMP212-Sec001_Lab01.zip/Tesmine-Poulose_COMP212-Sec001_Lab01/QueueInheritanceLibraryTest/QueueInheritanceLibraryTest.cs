﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QueueInheritanceLibrary;

namespace QueueInheritanceLibraryTest
{
    class QueueInheritanceLibraryTest
    {
        //main method
        static void Main(string[] args)
        {
            //create an object to store the values in the queue
            QueueInheritanceLibrary <int> intQueue = new QueueInheritanceLibrary <int>();

            //using method queue add values to the queue
            intQueue.queue(2560);
            intQueue.queue(2036);
            intQueue.queue(1256);
            intQueue.queue(0235);
            intQueue.queue(4569);
            intQueue.queue(8569);
            intQueue.queue(7458);
            intQueue.queue(4523);

            Console.WriteLine("....Queue with integer elements... ");
            intQueue.Display();
            Console.WriteLine($"Last element in the queue is: " +intQueue.GetLast());

        }//end of main method
    }//end of class
}//end of namepsace

