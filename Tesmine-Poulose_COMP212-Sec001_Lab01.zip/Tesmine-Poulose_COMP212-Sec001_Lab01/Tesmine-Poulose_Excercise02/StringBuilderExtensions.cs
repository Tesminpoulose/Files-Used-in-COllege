﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//coded by: Tesmine Poulose
//project name: COMP212 lab assignment 1
//Date : 28/05/2021

namespace Tesmine_Poulose_Excercise02
{
    //declaring StringBuilderExtensions class
    public static class StringBuilderExtensions
    {
        //declaring method

        public static int CountWord(this StringBuilder strObject)
        {
            //variable initialization , value set as zero
            int countword = 0;
            //using strbuilder we are splitting words in array 
            string[] string_array = strObject.ToString().Split(' ');
            //checking the array length 
            if (string_array.Length > 0)
            {
                //if length of the array is  greater than 0, countword is assigned its  length
                countword = string_array.Length;
            }
            //return countword
            return countword;
        } //end of CountWord method
    } //end of class StringBuilderExtensions
}//end of namespace