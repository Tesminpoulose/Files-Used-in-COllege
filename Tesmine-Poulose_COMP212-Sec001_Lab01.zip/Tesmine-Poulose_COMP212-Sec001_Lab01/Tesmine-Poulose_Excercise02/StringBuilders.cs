﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//coded by: Tesmine Poulose
//project name: COMP212 lab assignment 1
//Date : 28/05/2021

namespace Tesmine_Poulose_Excercise02
{
    class StringBuilders
    {
        //main method
        static void Main(string[] args)
        {

            Console.WriteLine(".....WORD COUNT....");
            Console.WriteLine();


            StringBuilder strobj = new StringBuilder();//declaring object 1 : strobj
            strobj.Append("This is to test whether the extension method count can return a right answer or not");
            Console.WriteLine($" First String :  This is to test whether the extension method count can return a right answer or not"); //example sentence from the Assignment 1 question
            Console.WriteLine($"Word count for the first string is   : " + strobj.CountWord());
            Console.WriteLine();


            //declaring object 2 : strobj1
            StringBuilder strobj2 = new StringBuilder();
            strobj2.Append("You can define extension methods for user defined types as well as predefined types");
            Console.WriteLine($" Second  String :You can define extension methods for user defined types as well as predefined types");//example sentence from the Assignment 1 question
            Console.WriteLine($"Word count for the Second string is   : " + strobj2.CountWord());
            Console.WriteLine();



            //declaring object 3 : strobj3
            StringBuilder strobj3 = new StringBuilder();
            strobj3.Append("C# program for counting words in a sentence");
            Console.WriteLine($" Third String :C# program for counting words in a sentence ");
            Console.WriteLine($"Word count for the Third string is   : " + strobj3.CountWord());
            Console.WriteLine();



        }      //end of main method
    }         //end of class StringBuilders
}//end of namespace