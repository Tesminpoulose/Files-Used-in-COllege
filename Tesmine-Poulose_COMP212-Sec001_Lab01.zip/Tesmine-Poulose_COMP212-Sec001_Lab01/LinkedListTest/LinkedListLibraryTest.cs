﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkedListLibraryTest
{
    class LinkedListLibraryTest
    {
        static void Main(string[] args)
        {
            LinkedListLibrary.List<int> list = new LinkedListLibrary.List<int>();
            LinkedListLibrary.List<double> listDouble = new LinkedListLibrary.List<double>();

            // lists of integers
            int anInteger = 5526;
            int anInteger1 = 5489;
            int anInteger2 = 2035;
            int anInteger3 = 459;
            int anInteger4 = 598;

            // lists of doubles
            double aDouble = 5689.23;
            double aDouble1 = 2568.36;
            double aDouble2 = 2579.36;
            double aDouble3 = 698.02;
            double aDouble4 = 698.02;


            // List insert methods
            list.InsertAtFront(anInteger);
            list.InsertAtFront(anInteger1);
            list.InsertAtBack(anInteger2);
            list.InsertAtBack(anInteger3);
            list.InsertAtBack(anInteger4);

            Console.WriteLine("......List Of Integers.......");
            Console.WriteLine();
            list.Display();
            Console.WriteLine($"Last element in the linked  list integer  is : "+list.GetLastNode());


            //double values added to the linkedList 
            listDouble.InsertAtFront(aDouble);
            listDouble.InsertAtFront(aDouble1);
            listDouble.InsertAtBack(aDouble2);
            listDouble.InsertAtBack(aDouble3);
            listDouble.InsertAtBack(aDouble4);

            Console.WriteLine("......List Of Doubles.......");
            Console.WriteLine();
            listDouble.Display();
            Console.WriteLine($"Last element in the linked list double is :"+listDouble.GetLastNode());
        } // end main
    }
}//end of namespace
