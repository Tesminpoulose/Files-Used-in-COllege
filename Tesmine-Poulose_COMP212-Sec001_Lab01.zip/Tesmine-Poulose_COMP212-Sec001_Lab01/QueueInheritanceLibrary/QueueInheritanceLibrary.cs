﻿using System;
using LinkedListLibrary;

namespace QueueInheritanceLibrary
{
    public class QueueInheritanceLibrary<T> : List <T>
    {
        public QueueInheritanceLibrary() : base("Queue with elements") { }

            // place Value at end of queue by inserting 
            public void queue(T value)
            {
            InsertAtBack(value);
            }

            // remove item from front of queue 
            public object Removequeue()
            {
            return RemoveFromFront();
            }

            // method gives us the last element 
            public T GetLast()
            {
                return this.GetLastNode();
            }//end of method
    }//end of class
    }//end of namespace

