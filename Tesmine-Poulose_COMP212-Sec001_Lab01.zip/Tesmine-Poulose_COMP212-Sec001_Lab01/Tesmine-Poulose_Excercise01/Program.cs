﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//coded by: Tesmine Poulose
//project name: COMP212 lab assignment 1
//Date : 28/05/2021

namespace Tesmine_Poulose_Excercise01
{
    class SearchValue

    {
        //Generic method
       private static int Search<T>(T[] dataArray, T searchKey) where T : IComparable<T>
        {
            int indexvalue = -1;

            //array length checking condition 
            if (dataArray.Length == 0)

            {
                throw new Exception("Array does not contain any values");
            }

            for (int i = 0; i < dataArray.Length; i++)
            {//loop will go through the array

                //we are using  compareto if == 0 means that the element in the array is equal to the search key
                if (dataArray[i].CompareTo(searchKey) == 0)
                {
                    return indexvalue = i;// if yes return the index value 
                }

            }

            //if was not found
            return indexvalue;
        } //end of loop



        //starting main method
        static void Main(string[] args)
        {
            String[] arraystr = { "Tesmin", "Ann", "Lettisha", "Neena", "Akshaya", "Joe", "Arun", "Bob", "james", "Job" };//create a array of strings

            Console.WriteLine("..........INDEX POSITION OF STRING VALUES........");
            Console.WriteLine();
            // searches and prints the result of searching the word Lettisha in the array
            Console.WriteLine($"String Lettisha is at the index position  of : {Search(arraystr, "Lettisha")}");
            // searches and prints the result of searching the word Mary in the array
            Console.WriteLine($"String Mary is at the index position of : {Search(arraystr, "Mary")}");
            Console.WriteLine();

            int[] arrayinteger = { 3, 4, 10, 1, 2, 6, 8, 12, 20, 22 };//create a array of integers
            Console.WriteLine("..........INDEX POSITION OF INTEGER VALUES........");
            Console.WriteLine();
            // searches and prints the result of searching the integer 22 in the array
            Console.WriteLine($"Integer is 22 at the index position of : " + Search(arrayinteger, 22));
            // searches and prints the result of searching the integer 60 in the array
            Console.WriteLine($"Integer is 60 at the index position of : " + Search(arrayinteger, 60));


        }//end of main method
    }//end of generic method
}//end of namespace
