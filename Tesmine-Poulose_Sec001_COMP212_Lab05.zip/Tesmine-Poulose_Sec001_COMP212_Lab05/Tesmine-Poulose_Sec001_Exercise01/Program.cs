﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// /finishing the console application Q1Lab3
/// coded on 04-08-2021
/// </summary>
namespace tesmine
    {
     class Program
       {
    static void Main(string[] args)
    {
     Console.WriteLine("\nList the names of the countries in alphabetical order");
     Console.WriteLine("******************************************************");
     var countryNames = Country.GetCountries().OrderBy((country) => country.Name).Select((country) => country.Name);
            
        foreach (var item in countryNames)
        {
            Console.WriteLine(item);
        }

    //List the names of the countries in descending order of number of resources
            
    var orderNoofRes = Country.GetCountries().OrderByDescending((country) => country.Resources.Count).Select((country) => country.Name);

     Console.WriteLine("\nList the names of the countries in descending order of number of resource");
            Console.WriteLine("***************************************************************************");

            foreach (var item in orderNoofRes)
            {
            Console.WriteLine(item);
            }

        // List the names of the countries that shares a border with Argentina
     var CountryBorderArg = Country.GetCountries().Where((aCountry) => aCountry.Borders.Contains("Argentina")).Select((aCountry) => aCountry.Name);

    Console.WriteLine("\nList the names of the countries that shares a border with Argentina");
    Console.WriteLine("*********************************************************************");

            foreach (var item in CountryBorderArg)
            {
            Console.WriteLine(item);
            }

  // List the names of the countries that has more than 10,000,000 population
     var countrieswithhighPop = Country.GetCountries().Where((aCountry) => aCountry.Population > 10000000).Select((aCOuntry) => aCOuntry.Name);
        
            Console.WriteLine("\nList the names of the countries that has more than 10,000,000 population");
            Console.WriteLine("**************************************************************************");

            foreach (var item in countrieswithhighPop)
            {
                Console.WriteLine(item);   
            }

     //List the country with highest population
    var countrywithmaxPop = Country.GetCountries().OrderByDescending((aCountry) => aCountry.Population);

     Console.WriteLine("\nList the country with highest population ");
     Console.WriteLine("******************************************************");

            var listCountry = countrywithmaxPop.ToList();

            Console.WriteLine(listCountry[0].Name);
            

            //List all the religion in south America in dictionary order

    var religionListing = Country.GetCountries().SelectMany((aCountry) => aCountry.Religions).OrderBy((aRelegion) => aRelegion).Distinct();

        Console.WriteLine("\nList all the religion in south America in dictionary order ");
        Console.WriteLine("***********************************************************");

            foreach (var item in religionListing)
             {
            Console.WriteLine(item);
                
            }//end of for each 

      }
   }//end of class
}//end of namespace