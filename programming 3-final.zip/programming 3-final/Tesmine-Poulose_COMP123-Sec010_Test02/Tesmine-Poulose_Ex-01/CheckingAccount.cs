﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountsApp
{
    //This class is derived from the abstract Account class
    class CheckingAccount : Account
        {
            const double TransactionFee = 0.70;
            public double WithdrawLimit { get; set; }

        //This constructor takes 4 arguments and populates the properties of the CheckingAccount
            public CheckingAccount(int number, string clientName, double balance, double withdrawLimit) : base(number, clientName, balance)
            {
                WithdrawLimit = withdrawLimit;
            }
        //This is a concrete method.
        public override void Deposit(double amount)
            {
                Balance += amount;
                Balance -= TransactionFee;
            }

            public override void Withdraw(double amount)
            {
                Balance -= amount;
                Balance -= TransactionFee;
            }//end of method
        }//end of class
    }//end of namespace

