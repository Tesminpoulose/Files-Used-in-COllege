﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountsApp
{
    abstract class Account
    {
        //declaring variables
      public double Balance { get; set; }
        public string ClientName { get; set; }
        public int Number { get; set; }

        public bool IsCheckingAccount { get; set; }

        //method with 3 arguments
        public Account(int number, string clientName, double balance)
        {
            Number = number;
            ClientName = clientName;
            Balance = balance;
        }
        //abstract method with one argument
        public abstract void Deposit(double amount);
        public abstract void Withdraw(double amount);
    }
}

