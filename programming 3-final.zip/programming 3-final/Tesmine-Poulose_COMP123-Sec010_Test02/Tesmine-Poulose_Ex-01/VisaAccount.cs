﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountsApp
{
    //This class is derived from the abstract Account class
    class VisaAccount : Account
    {
        const double TransactionFee = 3.5;
        public double InterestRate { get; set; }
        //This constructor takes 4 arguments and populates the properties of the VisaAccount
        public VisaAccount(int number, string clientName, double balance, double interestRate) : base(number, clientName, balance)
        {
            InterestRate = interestRate;
        }

        //This is a concrete method. It should 
        //add the amount to the Account Balance and deduct a $2.00 transaction fee from the Account Balance as 
        //well.The $2.00 fee should be coded as a class constant.
        public override void Deposit(double amount)
        {
            Balance += amount;
            Balance -= TransactionFee;
        }
        //This is a concrete method. It should 
        //deduct the amount from the Account Balance and deduct a $2.00 transaction fee from the Account
        //Balance as well.The $2.00 fee should be coded as a class constant, the same used for the Deposit method.
        public override void Withdraw(double amount)
        {
            Balance -= amount;
            Balance -= TransactionFee;
        }//end of method
    }//end of class
}//end of namespace
