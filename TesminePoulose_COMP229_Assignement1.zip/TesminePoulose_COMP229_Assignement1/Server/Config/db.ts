export const LocalURI = "mongodb://localhost/clothing_store";
export const HostName = "localhost";