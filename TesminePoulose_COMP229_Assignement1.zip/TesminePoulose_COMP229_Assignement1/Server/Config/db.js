"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HostName = exports.LocalURI = void 0;
exports.LocalURI = "mongodb://localhost/clothing_store";
exports.HostName = "localhost";
//# sourceMappingURL=db.js.map